# ITEMS
from constants import *

#ADD LOGIC TO CALCULATE WHETHER ALLOWED TO USE POTION OR NOT.

class Item:
    def __init__(self, game, images, pos, quantity):
        self.game = game
        self.quantity = quantity
        self.images = images
        self.rect = self.images[0].get_rect(topleft=pos)
        self.active = False

    def render(self, screen):
        image = self.images[0]
        if self.quantity <= 0:
            image = self.images[1]
        elif self.active:
            image = pygame.transform.scale(image, (60,60))
        screen.blit(image, self.rect)
    
    def handle_mouse_down(self, event):
        if self.rect.collidepoint(event.pos):
            self.active = True
            self.handle_press()
        else:
            self.active = False
            
    def handle_mouse_up(self, event):
        self.active = False

    def handle_press(self):
        pass


class HealthItem(Item):
    def __init__(self, game):
        super().__init__(game, [health_NotUsed, health_used],(50,480), 2)

    def handle_press(self):
        if self.quantity > 0 and self.game.hero.health < 200:
            self.quantity -= 1
            self.game.hero.get_health(50)
            self.game.gui.update_health(0, self.game.hero.health)


class PoisonItem(Item):
    def __init__(self, game):
        super().__init__(game, [poison_NotUsed, poison_used],(150,480), 1)

    def handle_press(self):
        if self.quantity > 0 and self.game.enemy.health > 0:
            self.quantity -= 1
            self.game.enemy.take_damage(30)
            self.game.gui.update_health(1, self.game.enemy.health)
        
