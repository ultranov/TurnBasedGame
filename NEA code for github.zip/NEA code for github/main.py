#Working copy 20.04.23
import pygame, random
from constants import *

from gui import *
import time
pygame.init()

import random

pygame.display.set_caption('Turn Based Combat')

clock = pygame.time.Clock()

#Class for handling the cursors position and drawing an image over the top of it.

class Cursor:
    def __init__(self):
        pass
    
    def render(self, screen):
        #Getting the position of the mouse
        pos = pygame.mouse.get_pos()
        #Making the windows cursor image invisible
        pygame.mouse.set_visible(False)
        #Drawing the sword image over the cursor's position.
        screen.blit(sword_img, pos)

#Defining the main Character class (Which the Hero and Enemy class inherit)

class Character:
    def __init__(self, name, game, damage, health):
        self.game = game
        self.damage = damage
        self.health = health
        self.name = name
    #Core function that allows the Hero and Enemy to take damage.
    def take_damage(self, amount):
        self.health -= amount

    #Core function that allows the Hero and Enemy to be given more health.
    def get_health(self, amount):
        self.health += amount

#Defining Hero class

class Hero(Character):
    def __init__(self, game):
        super().__init__('hero', game, hero_damage, initial_hero_health)
        #Set variables for the Hero class
        self.name = 'hero'
        self.frame_index = 0
        self.update_time = pygame.time.get_ticks()
        self.images = []
        self.alive = True
        
        self.action = IDLE #0 = IDLE 1 = ATTACK 2 = HURT 3 = DEATH

        #Coordinates of Knight
        self.x = 175
        self.y = 320
        
        #load idle images
        temp_list = []
        for i in range(8):
                img = pygame.image.load(f'img/Knight/Idle/{i}.png')
                img = pygame.transform.scale(img, (img.get_width() * 3, img.get_height() * 3))
                temp_list.append(img)
        self.images.append(temp_list)
        #load attack images
        temp_list = []
        for i in range(8):
                img = pygame.image.load(f'img/Knight/Attack/{i}.png')
                img = pygame.transform.scale(img, (img.get_width() * 3, img.get_height() * 3))
                temp_list.append(img)
        self.images.append(temp_list)
        #load hurt images
        temp_list = []
        for i in range(3):
                img = pygame.image.load(f'img/Knight/Hurt/{i}.png')
                img = pygame.transform.scale(img, (img.get_width() * 3, img.get_height() * 3))
                temp_list.append(img)
        self.images.append(temp_list)
        #load death images
        temp_list = []
        for i in range(10):
                img = pygame.image.load(f'img/Knight/Death/{i}.png')
                img = pygame.transform.scale(img, (img.get_width() * 3, img.get_height() * 3))
                temp_list.append(img)
        self.images.append(temp_list)
        self.image = self.images[self.action][self.frame_index]
        self.rect = self.image.get_rect()
        self.rect.center = (self.x, self.y)

    def update(self):
        animation_cooldown = 100
        #handle animation
        #update image
        self.image = self.images[self.action][self.frame_index]
        #check if enough time has passed since the last update
        if pygame.time.get_ticks() - self.update_time > animation_cooldown:
            self.update_time = pygame.time.get_ticks()
            self.frame_index += 1
            #if the animation has run out then reset back to the start
        if self.frame_index >= len(self.images[self.action]):
                if self.action == 3:
                    self.frame_index = len(self.images[self.action]) - 1
                else:
                    self.Idle()

    def Hurt(self):
        self.action = HURT
        self.frame_index = 0
        self.update_time = pygame.time.get_ticks()
      

    def Death(self):
        self.action = DEATH
        self.frame_index = 0
        self.update_time = pygame.time.get_ticks()
        
    def Idle(self):
        self.action = IDLE
        self.frame_index = 0
        self.update_time = pygame.time.get_ticks()

		
    def Attack(self):
        #Set variables to Attack animation
        self.action = ATTACK
        self.frame_index = 0
        self.update_time = pygame.time.get_ticks()
        #deal damage to enemy
        game.enemy.health = game.enemy.health - hero_damage
        self.game.gui.update_health(1, self.game.enemy.health)
        self.game.enemy.Hurt()

        #check if target has died
        if self.game.enemy.health < 1:
            self.game.enemy.health = 0
            self.game.enemy.alive = False
            self.game.enemy.Death()


    def draw(self, screen):
        screen.blit(self.image, self.rect)

    def reset (self):
        self.alive = True
        self.potions = potion_amount
        self.health = HeroMaxHealth
        self.frame_index = 0
        self.action = 0
        self.update_time = pygame.time.get_ticks()

    def render(self, screen):
        self.draw(screen)
        self.update()
        


class Enemy(Character):
    def __init__(self, game, Hero):
        super().__init__('enemy', game, enemy_damage, initial_enemy_health)
        self.name = 'enemy'
        self.alive = True
        self.frame_index = 0
        self.update_time = pygame.time.get_ticks()
        self.images = []
        self.max_hp = EnemyMaxHealth
        #self.enemy_health = enemy_health
        
        self.rect = (100,100)

        self.action = IDLE #0 = IDLE 1 = ATTACK 2 = HURT 3 = DEATH

        #Coordinates of Enemy
        self.x = 600
        self.y = 335

        temp_list = []
        for i in range(8):
                img = pygame.image.load(f'img/Enemy/Idle/{i}.png')
                img = pygame.transform.scale(img, (img.get_width() * 3, img.get_height() * 3))
                temp_list.append(img)
        self.images.append(temp_list)
        #load attack images
        temp_list = []
        for i in range(8):
                img = pygame.image.load(f'img/Enemy/Attack/{i}.png')
                img = pygame.transform.scale(img, (img.get_width() * 3, img.get_height() * 3))
                temp_list.append(img)
        self.images.append(temp_list)
        #load hurt images
        temp_list = []
        for i in range(3):
                img = pygame.image.load(f'img/Enemy/Hurt/{i}.png')
                img = pygame.transform.scale(img, (img.get_width() * 3, img.get_height() * 3))
                temp_list.append(img)
        self.images.append(temp_list)
        #load death images
        temp_list = []
        for i in range(10):
                img = pygame.image.load(f'img/Enemy/Death/{i}.png')
                img = pygame.transform.scale(img, (img.get_width() * 3, img.get_height() * 3))
                temp_list.append(img)
        self.images.append(temp_list)
        self.image = self.images[self.action][self.frame_index]
        self.rect = self.image.get_rect()
        self.rect.center = (self.x, self.y)

    def Hurt(self):
        self.action = 2
        self.frame_index = 0

    def Death(self):
        self.action = 3
        self.frame_index = 0
        self.alive = False

        #Make sure health is zero
        if self.health < 1:
            self.health = 0

    def Idle(self):
        self.action = 0
        self.frame_index = 0
        self.update_time = pygame.time.get_ticks()

		
    def Attack(self):
        self.frame_index = 0
        #run attack animation
        self.action = 1
        #deal damage to enemy
        game.hero.health = game.hero.health - enemy_damage
        self.game.gui.update_health(0, self.game.hero.health)
        self.game.hero.Hurt()
        
        #check if target has died
        if self.game.hero.health < 1:
            self.game.hero.health = 0
            self.game.hero.alive = False
            self.game.hero.Death()

    def update(self):
        animation_cooldown = 100
        #handle animation
        #update image
        self.image = self.images[self.action][self.frame_index]
        #check if enough time has passed since the last update
        if pygame.time.get_ticks() - self.update_time > animation_cooldown:
            self.update_time = pygame.time.get_ticks()
            self.frame_index += 1
            #if the animation has run out then reset back to the start
        if self.frame_index >= len(self.images[self.action]):
                if self.action == 3:
                        self.frame_index = len(self.images[self.action]) - 1
                else:
                        self.Idle()

    def draw(self, screen):
        screen.blit(self.image, self.rect)

    def reset(self):
        self.alive = True
        self.potions = potion_amount
        self.health = EnemyMaxHealth
        self.frame_index = 0
        self.action = 0
        self.update_time = pygame.time.get_ticks()

    def render(self, screen):
        self.draw(screen)
        self.update()
        

        
class Game:
    def __init__(self):
        
        self.clock = pygame.time.Clock()
        self.screen =  pygame.display.set_mode((screen_width, screen_height))
        self.gameover = False
        self.game_objects = []

        self.hero = Hero(self)
        self.enemy = Enemy(self, Hero)
        self.gui = GUI(self)
        self.cursor = Cursor()

    def HealthCap(self):
        if self.enemy.health < 1:
            self.enemy.health = 0

        if self.hero.health < 1:
            self.hero.health = 0

    def process_events(self):
        clicked = False
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    pygame.quit()
                    return
                
            elif event.type == pygame.MOUSEBUTTONDOWN:
                self.gui.handle_mouse_down(event)
                if event.button == 1:
                    clicked = True
                else:
                    clicked = False

            elif event.type == pygame.MOUSEBUTTONUP:
                self.gui.handle_mouse_up(event)


            #KEYBIND FOR HEALTH POTION
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_h:
                    return

            #KEYBIND FOR POISON
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_p:
                    return

            #KEYBIND FOR ENEMY ATTACK (TESTING PURPOSES)
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    self.enemy.Attack()

        #control player actions
        #reset action variables
        attack = False
        potion = False
        #define other variables
        game_over = 0 # 0 = running 1 = player won -1 = player lost
        current_fighter = 1 # 1 = hero's turn 2 = enemy's turn
        total_fighters = 2
        action_cooldown = 0
        action_wait_time = 0
        enemy_list = []
        enemy_list.append(self.enemy)
        #create buttons
        restart_button = Button(self.screen, 330, 120, restart_img, 120, 30)
        #make sure mouse is visible
        pos = pygame.mouse.get_pos()
        for count, enemy in enumerate(enemy_list):
            if self.enemy.rect.collidepoint(pos):
                if clicked == True and self.enemy.alive == True:
                    attack = True

        print(action_cooldown)

                    
        #Main Turn Based Logic
        if game_over == 0:
            #player action
            if self.hero.alive == True:
                if current_fighter == 1:
                    action_cooldown += 1
                    if action_cooldown >= action_wait_time:
                        #look for player action
                        #attack
                        if attack == True:
                            self.hero.Attack()
                            current_fighter += 1
                            action_cooldown = 0

            else:
                game_over = -1


            #enemy action
            for count, enemy in enumerate(enemy_list):
                if current_fighter == 2 + count:
                    if self.enemy.alive == True:
                            action_cooldown += 1
                            if action_cooldown >= action_wait_time:
                                    #check if bandit needs to heal first
                                    if (self.enemy.health / self.enemy.max_hp) < 0.5:
                                            #check if the potion would heal the bandit beyond max health
                                            if self.enemy.max_hp - self.enemy.health > potion_hp:
                                                    heal_amount = potion_hp
                                            else:
                                                    heal_amount = self.enemy.max_hp - self.enemy.health
                                            self.enemy.health += heal_amount
                                            self.enemy.potions -= 1
                                            current_fighter += 1
                                            action_cooldown = 0
                                    #attack
                                    else:
                                            self.enemy.Attack()
                                            current_fighter += 1
                                            action_cooldown = 0
                    else:
                            current_fighter += 1

            #if all fighters have had a turn then reset
            if current_fighter > total_fighters:
                current_fighter = 1
                    

        #check if all enemies are dead
        alive_enemies = 0
        if self.enemy.alive == True:
            alive_enemies += 1
        if alive_enemies == 0:
                game_over = 1

        
        #check if game is over
        if game_over != 0:
            if game_over == 1:
                self.screen.blit(victory_img, (250, 50))
            if game_over == -1:
                self.screen.blit(defeat_img, (290, 50))
            if restart_button.draw():
                self.hero.reset()
                for enemy in enemy_list:
                    self.enemy.reset()
                    current_fighter = 1
                    action_cooldown = 0
                    game_over = 0
                    

        pygame.display.update()

                

    
    def update(self):
        dt = self.clock.get_time()
        for obj in self.game_objects:
            obj.update(dt)

    
    def render(self):
        self.screen.fill(BLACK)

        for obj in self.game_objects:
            obj.render(self.screen)


        self.HealthCap()
        self.gui.render(self.screen)
        self.screen.blit(background_img, (0,0)) 
        self.hero.render(self.screen)
        self.enemy.render(self.screen)
        self.cursor.render(self.screen)
        
        

    def run(self):
        while True:
            self.process_events()
            self.update()
            self.render()
            self.clock.tick(FPS)

            

if __name__ == "__main__":
    game = Game()
    game.run()
    
