import pygame
from constants import *
from items import *

pygame.font.init()
font = pygame.font.SysFont('Arial', 24)


class HealthBar:
    def __init__(self, game, posx, min_value, max_value, initial_value):
        self.game = game
        self.posx = posx
        self.min_value = min_value
        self.max_value = max_value
        self.value = initial_value

    def update(self):
        pass

    def draw_text(self, screen, text, font, text_colour):
        img = font.render(text, True, text_colour)
        rect = img.get_rect(topright=(self.posx-5, 435))
        screen.blit(img, rect)

    def render(self, screen):
        ratio = self.value / (self.max_value - self.min_value)
        pygame.draw.rect(screen, RED, (self.posx, 440, 150, 20))
        pygame.draw.rect(screen, GREEN, (self.posx, 440, 150 * ratio, 20))
        self.draw_text(screen,'{}/{}'.format(self.value,self.max_value), font, RED)
        


class GUI:
    def __init__(self, game):
        self.health_item = HealthItem(game)
        self.poison_item = PoisonItem(game)
        self.health_bars = [
            #Hero Healthbar
            HealthBar(game, 120, 0, HeroMaxHealth, game.hero.health),
            #Enemy Healthbar
            HealthBar(game, screen_width - 200, 0, EnemyMaxHealth, game.enemy.health)
        ]

    def update_health(self, bar_number, new_value):
        self.health_bars[bar_number].value = new_value

    def handle_mouse_down(self, event):
        self.health_item.handle_mouse_down(event)
        self.poison_item.handle_mouse_down(event)

    def handle_mouse_up(self, event):
        self.health_item.handle_mouse_up(event)
        self.poison_item.handle_mouse_up(event)

    def draw_text(self, screen, text, font, text_colour, x, y):
        img = font.render(text, True, text_colour)
        screen.blit(img, (x, y))

    def draw_panel(self, screen):
        screen.blit(panel_img, (0, screen_height - bottom_panel))

    def draw(self):
        screen.blit(self.image, self.rect)
		
    def render(self, screen):
        self.draw_panel(screen)
        self.health_item.render(screen)
        self.poison_item.render(screen)
        for item in self.health_bars:
            item.render(screen)

#BUTTON

#button class
class Button():
	def __init__(self, surface, x, y, image, size_x, size_y):
		self.image = pygame.transform.scale(image, (size_x, size_y))
		self.rect = self.image.get_rect()
		self.rect.topleft = (x, y)
		self.clicked = False
		self.surface = surface

	def draw(self):
		action = False
		pos = pygame.mouse.get_pos()

		if self.rect.collidepoint(pos):
			if pygame.mouse.get_pressed()[0] == 1 and self.clicked == False:
				action = True
				self.clicked = True

		if pygame.mouse.get_pressed()[0] == 0:
			self.clicked = False

		#draw button
		self.surface.blit(self.image, (self.rect.x, self.rect.y))

		return action
