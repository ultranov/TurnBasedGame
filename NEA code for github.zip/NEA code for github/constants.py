import pygame
import os
import random

pygame.mixer.init()

FPS = 60

# COLOURS
BLACK = (0,0,0)
WHITE = (255,255,255)
RED = (255,0,0)
GREEN = (0,255,0)
BLUE = (0,0,255)


# IMAGES
panel_img = pygame.image.load('img/Icons/panel.png')
sword_img = pygame.image.load('img/Icons/sword.png')
background_img = pygame.image.load('img/Background/Background.jpg')
restart_img = pygame.image.load('img/Icons/Buttons/restart.png')
victory_img = pygame.image.load('img/Icons/victory.png')
defeat_img = pygame.image.load('img/Icons/defeat.png')
health_used = pygame.image.load('img/Icons/Buttons/health_used.png')
health_NotUsed = pygame.image.load('img/Icons/Buttons/health_NotUsed.png')
poison_used = pygame.image.load('img/Icons/Buttons/poison_used.png')
poison_NotUsed = pygame.image.load('img/Icons/Buttons/poison_NotUsed.png')    
    
#Defining actions

IDLE = 0
ATTACK = 1
HURT = 2
DEATH = 3


#OTHER

bottom_panel = 150
screen_width = 800
screen_height = 400 + bottom_panel

potion_amount = 2
potion_hp = 50

poison_amount = 1
poison_hp = 40

fps = pygame.time.Clock()

###SOUNDS
##attackFx = pygame.mixer.Sound("sounds/attackFX.wav")
###deathFX = pygame.mixer.Sound("sounds/deathFX.wav")
##hurtFX = pygame.mixer.Sound("sounds/hurtFX.wav")
##victoryFX = pygame.mixer.Sound("sounds/victoryFX.wav")
##gameoverFX = pygame.mixer.Sound("sounds/gameoverFX.wav")

#HERO
initial_hero_health = 100
hero_damage = 10
HeroMaxHealth = 200

#ENEMY

initial_enemy_health = 200
enemy_damage = 20
EnemyMaxHealth = 200
